﻿using GoSportsAPI.Models.Users;

namespace GoSportsAPI.Interfaces.IRepositories
{
    public interface IUserProfileRepository : IRepository<UserProfile>
    {
    }
}
