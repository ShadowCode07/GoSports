﻿namespace GoSportsAPI.Dtos.Profiles
{
    public class UserProfileUpdateDto
    {
        public List<string>? Sports { get; set; }
    }
}
