﻿namespace GoSportsAPI.Dtos.Profiles
{
    public class UserProfileResponceDto
    {
        public List<string>? Sports { get; set; }
    }
}
