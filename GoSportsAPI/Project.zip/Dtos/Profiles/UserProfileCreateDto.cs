﻿namespace GoSportsAPI.Dtos.Profiles
{
    public class UserProfileCreateDto
    {
        public List<string>? Sports { get; set; }
    }
}
